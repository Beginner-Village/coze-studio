-- ============================================================
-- Ynet Loop Database Schema
-- Source: 10.10.10.226:3306 / cozeloop-mysql -> ynetloop-mysql
-- Exported: 2026-03-17
-- ============================================================
CREATE DATABASE IF NOT EXISTS `ynetloop-mysql` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ynetloop-mysql`;

CREATE TABLE `annotate_record` (
  `id` bigint unsigned NOT NULL COMMENT 'idgen record id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´idï¼Œåˆ†ç‰‡é”®',
  `tag_key_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ ‡ç­¾ id',
  `experiment_id` bigint unsigned NOT NULL COMMENT 'å®žéªŒid',
  `score` decimal(10,4) DEFAULT NULL COMMENT 'å¾—åˆ†ç»“æžœ',
  `text_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'æ–‡æœ¬ç»“æžœ',
  `annotate_data` mediumblob COMMENT 'æ ‡æ³¨ç»“æžœ, json',
  `created_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` bigint NOT NULL DEFAULT '0' COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'è½¯åˆ é™¤æ—¶é—´',
  `created_by` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ›å»ºäººuserID',
  `tag_value_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ ‡ç­¾å€¼ id',
  PRIMARY KEY (`id`),
  KEY `idx_space_id_experiment_id_tag_key_id` (`space_id`,`experiment_id`,`tag_key_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='annotate_record';

CREATE TABLE `api_key` (
  `id` bigint unsigned NOT NULL COMMENT 'Primary Key ID',
  `key` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'API Key hash',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'API Key Name',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '0 normal, 1 deleted',
  `user_id` bigint NOT NULL DEFAULT '0' COMMENT 'API Key Owner',
  `expired_at` bigint NOT NULL DEFAULT '0' COMMENT 'API Key Expired Time',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Created Time',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Updated Time',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'Deleted Time',
  `last_used_at` bigint NOT NULL DEFAULT '0' COMMENT 'Last Used Time',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='api key table';

CREATE TABLE `auto_task_run` (
  `id` bigint unsigned NOT NULL COMMENT 'TaskRun ID',
  `workspace_id` bigint unsigned NOT NULL COMMENT '空间ID',
  `task_id` bigint unsigned NOT NULL COMMENT 'Task ID',
  `task_type` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Task类型',
  `run_status` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Task Run状态',
  `run_detail` json DEFAULT NULL COMMENT 'Task Run运行状态详情',
  `backfill_detail` json DEFAULT NULL COMMENT '历史回溯Task Run运行状态详情',
  `run_start_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '任务开始时间',
  `run_end_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '任务结束时间',
  `run_config` json DEFAULT NULL COMMENT '相关Run的配置信息',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_task_id_status` (`task_id`,`run_status`),
  KEY `idx_workspace_task` (`workspace_id`,`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Task Run信息';

CREATE TABLE `dataset` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `app_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'åº”ç”¨ ID',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ ID',
  `schema_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Schema ID',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ•°æ®é›†åç§°',
  `description` varchar(2048) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ•°æ®é›†æè¿°',
  `category` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ä¸šåŠ¡åœºæ™¯åˆ†ç±»',
  `biz_category` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ä¸šåŠ¡åœºæ™¯ä¸‹è‡ªå®šä¹‰åˆ†ç±»',
  `status` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'çŠ¶æ€',
  `security_level` varchar(32) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'å®‰å…¨ç­‰çº§',
  `visibility` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'å¯è§æ€§',
  `spec` json DEFAULT NULL COMMENT 'è§„æ ¼é…ç½®',
  `features` json DEFAULT NULL COMMENT 'åŠŸèƒ½å¼€å…³',
  `latest_version` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æœ€æ–°ç‰ˆæœ¬å·',
  `next_version_num` bigint unsigned NOT NULL DEFAULT '1' COMMENT 'ä¸‹ä¸€ä¸ªç‰ˆæœ¬çš„æ•°å­—ç‰ˆæœ¬å·',
  `last_operation` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æœ€æ–°æ“ä½œ',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºäºº',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ä¿®æ”¹äºº',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ—¶é—´',
  `expired_at` timestamp NULL DEFAULT NULL COMMENT 'è¿‡æœŸæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_space_id_category_name` (`space_id`,`category`,`name`,`deleted_at`),
  KEY `idx_space_id_category_updated_at_id` (`space_id`,`category`,`updated_at`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7544955570130780162 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;æ•°æ®é›†';

CREATE TABLE `dataset_io_job` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `app_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'åº”ç”¨ ID',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ ID',
  `dataset_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ•°æ®é›† ID',
  `job_type` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ä»»åŠ¡ç±»åž‹',
  `source_file` json DEFAULT NULL COMMENT 'æºæ–‡ä»¶ä¿¡æ¯',
  `source_dataset` json DEFAULT NULL COMMENT 'æºæ•°æ®é›†ä¿¡æ¯',
  `target_file` json DEFAULT NULL COMMENT 'ç›®æ ‡æ–‡ä»¶ä¿¡æ¯',
  `target_dataset` json DEFAULT NULL COMMENT 'ç›®æ ‡æ•°æ®é›†ä¿¡æ¯',
  `field_mappings` json DEFAULT NULL COMMENT 'å­—æ®µæ˜ å°„',
  `option` json DEFAULT NULL COMMENT 'ä»»åŠ¡é€‰é¡¹',
  `status` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'çŠ¶æ€',
  `progress_total` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ€»æ•°',
  `progress_processed` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'å·²å¤„ç†çš„æ•°é‡',
  `progress_added` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'å·²å†™å…¥çš„æ•°é‡',
  `sub_progresses` json DEFAULT NULL COMMENT 'è¿›åº¦ä¿¡æ¯',
  `errors` json DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºäºº',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ä¿®æ”¹äºº',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `started_at` timestamp NULL DEFAULT NULL COMMENT 'å¼€å§‹æ—¶é—´',
  `ended_at` timestamp NULL DEFAULT NULL COMMENT 'ç»“æŸæ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_space_dataset` (`space_id`,`dataset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='æ•°æ®é›†å¯¼å…¥å¯¼å‡ºä»»åŠ¡';

CREATE TABLE `dataset_item` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `app_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'åº”ç”¨ ID',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ ID',
  `dataset_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ•°æ®é›† ID',
  `schema_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Schema ID',
  `item_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ¡ç›® ID',
  `item_key` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'å¹‚ç­‰ key',
  `data` json DEFAULT NULL COMMENT 'æ•°æ®å†…å®¹',
  `repeated_data` json DEFAULT NULL COMMENT 'å¤šè½®æ•°æ®å†…å®¹',
  `data_properties` json DEFAULT NULL COMMENT 'å†…å®¹å±žæ€§',
  `add_vn` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ·»åŠ ç‰ˆæœ¬å·',
  `del_vn` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤ç‰ˆæœ¬å·',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºäºº',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ä¿®æ”¹äºº',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ—¶é—´',
  `update_version` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ›´æ–°ç‰ˆæœ¬å·ï¼Œç”¨äºŽä¹è§‚é”',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dataset_add_vn_item_id_deleted_at` (`dataset_id`,`add_vn`,`item_id`,`deleted_at`),
  UNIQUE KEY `uk_dataset_add_vn_item_key_deleted_at` (`dataset_id`,`add_vn`,`item_key`,`deleted_at`),
  KEY `idx_dataset_del_vn_created_at_item` (`dataset_id`,`del_vn`,`created_at`,`item_id`),
  KEY `idx_dataset_del_vn_updated_at_item` (`dataset_id`,`del_vn`,`updated_at`,`item_id`),
  KEY `idx_dataset_add_vn_del_vn_item` (`dataset_id`,`add_vn`,`del_vn`,`item_id`),
  KEY `idx_dataset_del_vn_item_id` (`dataset_id`,`del_vn`,`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7540962802681249794 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;æ•°æ®é›†æ¡ç›®';

CREATE TABLE `dataset_item_snapshot` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `app_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'åº”ç”¨ ID',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ ID',
  `dataset_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ•°æ®é›† ID',
  `schema_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Schema ID',
  `version_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Version ID',
  `item_primary_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ¡ç›®ä¸»é”® ID',
  `item_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ¡ç›® ID',
  `item_key` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ¡ç›®å¹‚ç­‰ key',
  `data` json DEFAULT NULL COMMENT 'æ•°æ®å†…å®¹',
  `repeated_data` json DEFAULT NULL COMMENT 'å¤šè½®æ•°æ®å†…å®¹',
  `data_properties` json DEFAULT NULL COMMENT 'å†…å®¹å±žæ€§',
  `add_vn` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ·»åŠ ç‰ˆæœ¬å·',
  `del_vn` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤ç‰ˆæœ¬å·',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'snapshot åˆ›å»ºæ—¶é—´',
  `item_created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'item åˆ›å»ºäºº',
  `item_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'item åˆ›å»ºæ—¶é—´',
  `item_updated_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'item ä¿®æ”¹äºº',
  `item_updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'item ä¿®æ”¹æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_version_item` (`version_id`,`item_id`),
  KEY `idx_version_item_created_at_item` (`version_id`,`item_created_at`,`item_id`),
  KEY `idx_version_item_updated_at_item` (`version_id`,`item_updated_at`,`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7540962953021882370 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;æ•°æ®é›†æ¡ç›®å¿«ç…§';

CREATE TABLE `dataset_schema` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `app_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'åº”ç”¨ ID',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ ID',
  `dataset_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ•°æ®é›† ID',
  `fields` json NOT NULL COMMENT 'å­—æ®µæ ¼å¼',
  `immutable` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'æ˜¯å¦ä¸å…è®¸ç¼–è¾‘',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºäºº',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ä¿®æ”¹äºº',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `update_version` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ›´æ–°ç‰ˆæœ¬å·',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7544955570130796546 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;æ•°æ®é›† Schema';

CREATE TABLE `dataset_version` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `app_id` int unsigned NOT NULL DEFAULT '0' COMMENT 'åº”ç”¨ ID',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ ID',
  `dataset_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ•°æ®é›† ID',
  `schema_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Schema ID',
  `dataset_brief` json DEFAULT NULL COMMENT 'æ•°æ®é›†å…ƒä¿¡æ¯å¤‡ä»½',
  `version` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ç‰ˆæœ¬å·ï¼ŒSemVer2 ä¸‰æ®µå¼',
  `version_num` bigint unsigned NOT NULL DEFAULT '1' COMMENT 'æ•°å­—ç‰ˆæœ¬å·ï¼Œä»Ž1å¼€å§‹é€’å¢ž',
  `description` varchar(2048) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ç‰ˆæœ¬æè¿°',
  `item_count` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ¡æ•°',
  `snapshot_status` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'å¿«ç…§çŠ¶æ€',
  `snapshot_progress` json DEFAULT NULL COMMENT 'å¿«ç…§è¿›åº¦è¯¦æƒ…',
  `update_version` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ›´æ–°ç‰ˆæœ¬å·',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºäºº',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `disabled_at` timestamp NULL DEFAULT NULL COMMENT 'ç‰ˆæœ¬ç¦ç”¨æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_dataset_id_version` (`dataset_id`,`version`),
  KEY `idx_dataset_id_created_at_id` (`dataset_id`,`created_at`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7540962952791195650 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;æ•°æ®é›†ç‰ˆæœ¬';

CREATE TABLE `eval_target` (
  `id` bigint unsigned NOT NULL COMMENT 'idgen id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´id',
  `source_target_id` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'æ¥æºçš„å¯¹è±¡çš„IDï¼Œæ¯”å¦‚promptID',
  `target_type` int unsigned NOT NULL COMMENT 'è¯„ä¼°å¯¹è±¡ç±»åž‹',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'åˆ›å»ºäºº',
  `updated_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'æ›´æ–°äºº',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_space_id_source_target_id_target_type` (`space_id`,`source_target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;è¯„ä¼°å¯¹è±¡ä¿¡æ¯';

CREATE TABLE `eval_target_record` (
  `id` bigint unsigned NOT NULL COMMENT 'id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´id',
  `target_id` bigint unsigned NOT NULL COMMENT 'è¯„æµ‹å¯¹è±¡id',
  `target_version_id` bigint unsigned NOT NULL COMMENT 'ç‰ˆæœ¬ID',
  `experiment_run_id` bigint unsigned NOT NULL COMMENT 'å®žéªŒæ‰§è¡Œid',
  `item_id` bigint unsigned NOT NULL COMMENT 'è¯„æµ‹é›†è¡Œid',
  `turn_id` bigint unsigned NOT NULL COMMENT 'è¯„æµ‹é›†è¡Œè½®æ¬¡id',
  `log_id` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'log id',
  `trace_id` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'trace id',
  `input_data` mediumblob COMMENT 'è¾“å…¥, json',
  `output_data` mediumblob COMMENT 'è¾“å‡º, json',
  `status` int NOT NULL COMMENT 'æ‰§è¡ŒçŠ¶æ€',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;è¯„ä¼°å¯¹è±¡è®°å½•ä¿¡æ¯';

CREATE TABLE `eval_target_version` (
  `id` bigint unsigned NOT NULL COMMENT 'target version id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´id',
  `target_id` bigint unsigned NOT NULL COMMENT 'target id',
  `source_target_version` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'source target version',
  `target_meta` blob COMMENT 'å…·ä½“å†…å®¹, æ¯ç§é™æ€è§„åˆ™ç±»åž‹å¯¹åº”ä¸€ä¸ªè§£æžæ–¹å¼, json',
  `input_schema` blob COMMENT 'è¯„ä¼°å™¨è¾“å…¥ç»“æž„ä¿¡æ¯, json',
  `output_schema` blob COMMENT 'è¯„ä¼°å™¨è¾“å‡ºç»“æž„ä¿¡æ¯, json',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'åˆ›å»ºäºº',
  `updated_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'æ›´æ–°äºº',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_space_id_target_id_source_target_version` (`space_id`,`target_id`,`source_target_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;è¯„ä¼°å¯¹è±¡ç‰ˆæœ¬ä¿¡æ¯';

CREATE TABLE `evaluator` (
  `id` bigint unsigned NOT NULL COMMENT 'idgen id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´id',
  `evaluator_type` int unsigned NOT NULL COMMENT 'è¯„ä¼°å™¨ç±»åž‹',
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'åç§°',
  `description` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'æè¿°',
  `draft_submitted` tinyint(1) DEFAULT '0' COMMENT 'è‰ç¨¿æ˜¯å¦å·²æäº¤',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'åˆ›å»ºäºº',
  `updated_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'æ›´æ–°äºº',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `latest_version` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æœ€æ–°ç‰ˆæœ¬å·',
  `evaluator_info` blob COMMENT '评估器补充信息, json',
  `builtin` int unsigned NOT NULL DEFAULT '2' COMMENT '是否预置，1:是；2:否',
  `box_type` int unsigned NOT NULL DEFAULT '1' COMMENT '黑白盒类型，1:白盒；2:黑盒',
  `builtin_visible_version` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '预置评估器最新可见版本号',
  PRIMARY KEY (`id`),
  KEY `idx_space_id_evaluator_type` (`space_id`,`evaluator_type`),
  KEY `idx_space_id_created_by` (`space_id`,`created_by`),
  KEY `idx_space_id_created_at` (`space_id`,`created_at`),
  KEY `idx_space_id_updated_at` (`space_id`,`updated_at`),
  KEY `idx_space_id_name` (`space_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;è¯„ä¼°å™¨ä¿¡æ¯';

CREATE TABLE `evaluator_record` (
  `id` bigint unsigned NOT NULL COMMENT 'idgen id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´id',
  `evaluator_version_id` bigint unsigned NOT NULL COMMENT 'è¯„ä¼°å™¨ç‰ˆæœ¬id',
  `experiment_id` bigint unsigned DEFAULT NULL COMMENT 'å®žéªŒid',
  `experiment_run_id` bigint unsigned NOT NULL COMMENT 'å®žéªŒæ‰§è¡Œid',
  `item_id` bigint unsigned NOT NULL COMMENT 'è¯„ä¼°é›†è¡Œid',
  `turn_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'è¯„ä¼°é›†è¡Œè½®æ¬¡id',
  `log_id` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'log id',
  `trace_id` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'trace id',
  `score` decimal(10,4) DEFAULT NULL COMMENT 'å¾—åˆ†',
  `status` int NOT NULL COMMENT 'æ‰§è¡ŒçŠ¶æ€',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `input_data` mediumblob COMMENT 'è¾“å…¥, json',
  `output_data` mediumblob COMMENT 'æ‰§è¡Œç»“æžœ, json',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'åˆ›å»ºäºº',
  `updated_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'æ›´æ–°äºº',
  `ext` mediumblob COMMENT 'è¡¥å……ä¿¡æ¯, json',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;è¯„ä¼°å™¨æ‰§è¡Œç»“æžœ';

CREATE TABLE `evaluator_tag` (
  `id` bigint unsigned NOT NULL COMMENT 'idgen id',
  `source_id` bigint unsigned NOT NULL COMMENT '资源id',
  `tag_type` int unsigned NOT NULL COMMENT 'tag类型，1:评估器；2:模板',
  `tag_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'tag键',
  `tag_value` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'tag值',
  `lang_type` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'zh' COMMENT '语言类型',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '创建人',
  `updated_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '更新人',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `idx_source_id` (`source_id`),
  KEY `idx_tag_type_tag_key_tag_value` (`tag_type`,`tag_key`,`tag_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;评估器tag';

CREATE TABLE `evaluator_template` (
  `id` bigint unsigned NOT NULL COMMENT 'idgen id',
  `space_id` bigint unsigned DEFAULT NULL COMMENT '空间id',
  `evaluator_type` int unsigned DEFAULT NULL COMMENT '评估器类型',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '名称',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '版本描述',
  `metainfo` blob COMMENT '具体内容, 每种静态规则类型对应一个解析方式, json',
  `receive_chat_history` tinyint(1) DEFAULT '0' COMMENT '是否需求传递上下文',
  `input_schema` blob COMMENT '评估器结构信息, json',
  `output_schema` blob COMMENT '评估器结构信息, json',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '创建人',
  `updated_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '更新人',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  `popularity` bigint unsigned NOT NULL DEFAULT '0' COMMENT '热度',
  `evaluator_info` blob COMMENT '评估器补充信息, json',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;评估器模板';

CREATE TABLE `evaluator_version` (
  `id` bigint unsigned NOT NULL COMMENT 'idgen id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´id',
  `evaluator_type` int unsigned DEFAULT NULL COMMENT 'è¯„ä¼°å™¨ç±»åž‹',
  `evaluator_id` bigint unsigned NOT NULL COMMENT 'è¯„ä¼°å™¨id',
  `version` varchar(128) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ç‰ˆæœ¬å·',
  `description` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ç‰ˆæœ¬æè¿°',
  `metainfo` blob COMMENT 'å…·ä½“å†…å®¹, æ¯ç§é™æ€è§„åˆ™ç±»åž‹å¯¹åº”ä¸€ä¸ªè§£æžæ–¹å¼, json',
  `receive_chat_history` tinyint(1) DEFAULT '0' COMMENT 'æ˜¯å¦éœ€æ±‚ä¼ é€’ä¸Šä¸‹æ–‡',
  `input_schema` blob COMMENT 'è¯„ä¼°å™¨ç»“æž„ä¿¡æ¯, json',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'åˆ›å»ºäºº',
  `updated_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'æ›´æ–°äºº',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `output_schema` blob COMMENT '评估器输出schema, json',
  PRIMARY KEY (`id`),
  KEY `idx_evaluator_id_version` (`evaluator_id`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='NDB_SHARE_TABLE;è¯„ä¼°å™¨ç‰ˆæœ¬ä¿¡æ¯';

CREATE TABLE `experiment` (
  `id` bigint unsigned NOT NULL COMMENT 'id',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ id',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºè€… id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'å®žéªŒåç§°',
  `description` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'å®žéªŒæè¿°',
  `eval_set_version_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'è¯„æµ‹é›†ç‰ˆæœ¬ id',
  `target_type` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'è¯„ä¼°å¯¹è±¡ç±»åž‹',
  `target_version_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'è¯„ä¼°å¯¹è±¡ç‰ˆæœ¬ id',
  `eval_conf` blob COMMENT 'å®žéªŒè¯„ä¼°æµç¨‹é…ç½®',
  `status` int unsigned NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `status_message` blob COMMENT 'çŠ¶æ€æç¤ºä¿¡æ¯',
  `start_at` timestamp NULL DEFAULT NULL COMMENT 'å¼€å§‹æ‰§è¡Œæ—¶é—´',
  `end_at` timestamp NULL DEFAULT NULL COMMENT 'ç»“æŸæ‰§è¡Œæ—¶é—´',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `latest_run_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æœ€åŽè¿è¡Œid',
  `target_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'è¯„ä¼°å¯¹è±¡ id',
  `eval_set_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'è¯„æµ‹é›† id',
  `expt_template_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '实验模板 id',
  `credit_cost` int NOT NULL DEFAULT '0' COMMENT 'æƒç›Šæ¶ˆè€—æ¨¡å¼',
  `source_type` int unsigned NOT NULL DEFAULT '1' COMMENT 'å®žéªŒæ¥æºç±»åž‹ï¼Œè¯„æµ‹:1,è‡ªåŠ¨åŒ–ä»»åŠ¡:2...',
  `source_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT 'å®žéªŒæ¥æºid',
  `expt_type` int unsigned NOT NULL DEFAULT '1' COMMENT 'å®žéªŒç±»åž‹ï¼Œoffline:1,online:2...',
  `max_alive_time` bigint unsigned DEFAULT NULL COMMENT 'æœ€å¤§å­˜æ´»æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_expt_item_idx` (`space_id`,`name`,`deleted_at`),
  KEY `idx_space_deleted_created_by` (`space_id`,`created_by`,`deleted_at`),
  KEY `idx_space_deleted_status` (`space_id`,`status`,`deleted_at`),
  KEY `idx_deleted_dataset` (`space_id`,`eval_set_version_id`,`deleted_at`),
  KEY `idx_deleted_target_type` (`space_id`,`target_type`,`deleted_at`),
  KEY `idx_target_id_delete_at` (`space_id`,`target_id`,`deleted_at`),
  KEY `idx_eval_set_id_delete_at` (`space_id`,`eval_set_id`,`deleted_at`),
  KEY `idx_space_start_at` (`space_id`,`start_at`),
  KEY `idx_space_end_at` (`space_id`,`end_at`),
  KEY `idx_source_type_source_id` (`source_type`,`source_id`),
  KEY `idx_space_expt_template_id_delete_at` (`space_id`,`expt_template_id`,`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='experiment';

CREATE TABLE `expt_aggr_result` (
  `id` bigint unsigned NOT NULL COMMENT 'idgen id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´id',
  `experiment_id` bigint unsigned NOT NULL COMMENT 'å®žéªŒid',
  `field_type` int DEFAULT NULL COMMENT 'èšåˆå­—æ®µç±»åž‹ 1ï¼šè¯„ä¼°å™¨å¾—åˆ†',
  `field_key` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'èšåˆå­—æ®µå”¯ä¸€æ ‡è¯†',
  `score` decimal(10,4) DEFAULT NULL COMMENT 'èšåˆåŽçš„å¹³å‡å¾—åˆ†',
  `aggr_result` blob COMMENT 'è¯¦ç»†èšåˆç»“æžœ',
  `version` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç‰ˆæœ¬å·(ç”¨äºŽä¹è§‚é”)',
  `status` int NOT NULL COMMENT 'è®¡ç®—çŠ¶æ€ 1:idle 2: caculating',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_experiment_id_field_type_field_key` (`experiment_id`,`field_type`,`field_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='å®žéªŒèšåˆç»“æžœè¡¨';

CREATE TABLE `expt_evaluator_ref` (
  `id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'id',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ id',
  `expt_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'å®žéªŒ id',
  `evaluator_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'è¯„ä¼°å™¨ id',
  `evaluator_version_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'è¯„ä¼°å™¨ç‰ˆæœ¬ id',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_space_expt` (`space_id`,`expt_id`),
  KEY `idx_space_evaluator` (`space_id`,`evaluator_id`),
  KEY `idx_space_evaluator_version` (`space_id`,`evaluator_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_evaluator_ref';

CREATE TABLE `expt_insight_analysis_feedback_comment` (
  `id` bigint unsigned NOT NULL COMMENT '唯一标识 idgen生成',
  `space_id` bigint unsigned NOT NULL COMMENT 'SpaceID',
  `expt_id` bigint unsigned NOT NULL COMMENT 'exptID',
  `analysis_record_id` bigint unsigned DEFAULT NULL COMMENT '洞察分析记录ID',
  `comment` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '评论内容',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '创建者 id',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `idx_space_id_expt_id_analysis_record_id_created_by` (`space_id`,`expt_id`,`analysis_record_id`,`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='实验洞察分析反馈评论表';

CREATE TABLE `expt_insight_analysis_feedback_vote` (
  `id` bigint unsigned NOT NULL COMMENT '唯一标识 idgen生成',
  `space_id` bigint unsigned NOT NULL COMMENT 'SpaceID',
  `expt_id` bigint unsigned NOT NULL COMMENT 'exptID',
  `vote_type` int NOT NULL COMMENT '反馈类型',
  `analysis_record_id` bigint unsigned DEFAULT NULL COMMENT '洞察分析记录ID',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '创建者 id',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_space_id_expt_id_analysis_record_id_created_by` (`space_id`,`expt_id`,`analysis_record_id`,`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='实验洞察分析反馈点赞表';

CREATE TABLE `expt_insight_analysis_record` (
  `id` bigint unsigned NOT NULL COMMENT '唯一标识 idgen生成',
  `space_id` bigint unsigned NOT NULL COMMENT 'SpaceID',
  `expt_id` bigint unsigned NOT NULL COMMENT 'exptID',
  `status` int NOT NULL COMMENT '状态',
  `expt_result_file_path` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '原始报告文件路径',
  `analysis_report_id` bigint unsigned DEFAULT NULL COMMENT '洞察分析报告ID',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '创建者 id',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `idx_space_id_expt_id` (`space_id`,`expt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='实验洞察分析记录表';

CREATE TABLE `expt_item_result` (
  `id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'id',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ id',
  `expt_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'å®žéªŒ id',
  `expt_run_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'å®žéªŒè¿è¡Œ id',
  `item_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'item_id',
  `item_idx` int unsigned DEFAULT NULL COMMENT 'item åºå·',
  `status` int unsigned NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `err_msg` blob COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `log_id` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ—¥å¿— id',
  `ext` blob COMMENT '补充信息',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_expt_item_idx` (`space_id`,`expt_id`,`item_id`),
  KEY `idx_expt_status` (`space_id`,`expt_id`,`status`),
  KEY `idx_expt_item_turn_idx` (`space_id`,`expt_id`,`item_idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_item_result';

CREATE TABLE `expt_item_result_run_log` (
  `id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'id',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ id',
  `expt_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'å®žéªŒ id',
  `expt_run_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'å®žéªŒè¿è¡Œ id',
  `item_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'item_id',
  `status` int unsigned NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `err_msg` blob COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `log_id` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ—¥å¿— id',
  `result_state` int DEFAULT NULL COMMENT 'å›žå†™ç»“æžœè¡¨çŠ¶æ€',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_expt_run_item_turn` (`space_id`,`expt_id`,`expt_run_id`,`item_id`),
  KEY `idx_expt_item_turn` (`space_id`,`expt_id`,`item_id`),
  KEY `idx_expt_run_result_state` (`space_id`,`expt_id`,`expt_run_id`,`result_state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_item_result_run_log';

CREATE TABLE `expt_result_export_record` (
  `id` bigint unsigned NOT NULL COMMENT 'export_id å¯¼å‡ºçš„å”¯ä¸€æ ‡è¯† idgenç”Ÿæˆ',
  `space_id` bigint unsigned NOT NULL COMMENT 'SpaceID',
  `expt_id` bigint unsigned NOT NULL COMMENT 'exptID',
  `csv_export_status` int NOT NULL COMMENT 'CSVå¯¼å‡ºçŠ¶æ€ï¼š1-å¯¼å‡ºä¸­, 2-å¯¼å‡ºæˆåŠŸ 3-å¯¼å‡ºå¤±è´¥',
  `file_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'tosæ–‡ä»¶è·¯å¾„',
  `start_at` timestamp NULL DEFAULT NULL COMMENT 'å¼€å§‹æ‰§è¡Œæ—¶é—´',
  `end_at` timestamp NULL DEFAULT NULL COMMENT 'ç»“æŸæ‰§è¡Œæ—¶é—´',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºè€… id',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `err_msg` blob COMMENT 'é”™è¯¯ä¿¡æ¯',
  PRIMARY KEY (`id`),
  KEY `idx_space_id_expt_id` (`space_id`,`expt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='å®žéªŒå¯¼å‡ºä¿¡æ¯è¡¨';

CREATE TABLE `expt_run_log` (
  `id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'id',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ id',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºè€… id',
  `expt_id` bigint NOT NULL COMMENT 'å®žéªŒ id',
  `expt_run_id` bigint NOT NULL COMMENT 'è¿è¡Œ id',
  `item_ids` blob COMMENT 'ç»„ ids',
  `mode` int DEFAULT NULL COMMENT 'æ¨¡å¼',
  `status` bigint DEFAULT NULL COMMENT 'çŠ¶æ€',
  `pending_cnt` int unsigned NOT NULL DEFAULT '0' COMMENT 'item æœªæ‰§è¡Œæ•°é‡',
  `success_cnt` int unsigned NOT NULL DEFAULT '0' COMMENT 'item æˆåŠŸæ•°é‡',
  `fail_cnt` int unsigned NOT NULL DEFAULT '0' COMMENT 'item å¤±è´¥æ•°é‡',
  `credit_cost` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT 'credit æ¶ˆè€—',
  `token_cost` bigint DEFAULT NULL COMMENT 'token æ¶ˆè€—',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `status_message` blob COMMENT 'æç¤ºä¿¡æ¯',
  `processing_cnt` int NOT NULL DEFAULT '0' COMMENT 'processing_cnt',
  `terminated_cnt` int NOT NULL DEFAULT '0' COMMENT 'terminated_cnt',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_expt_run` (`space_id`,`expt_id`,`expt_run_id`),
  KEY `idx_expt_run_item_turn` (`space_id`,`expt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_run_log';

CREATE TABLE `expt_stats` (
  `id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'id',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ id',
  `expt_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'å®žéªŒ id',
  `pending_cnt` int NOT NULL DEFAULT '0' COMMENT 'pending_cnt',
  `success_cnt` int NOT NULL DEFAULT '0' COMMENT 'success_cnt',
  `fail_cnt` int NOT NULL DEFAULT '0' COMMENT 'fail_cnt',
  `credit_cost` decimal(15,2) NOT NULL DEFAULT '0.00' COMMENT 'credit æ¶ˆè€—',
  `input_token_cost` bigint DEFAULT NULL COMMENT 'input token æ¶ˆè€—',
  `output_token_cost` bigint DEFAULT NULL COMMENT 'output token æ¶ˆè€—',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `processing_cnt` int NOT NULL DEFAULT '0' COMMENT 'processing_cnt',
  `terminated_cnt` int NOT NULL DEFAULT '0' COMMENT 'terminated_cnt',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_space_expt` (`space_id`,`expt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_stats';

CREATE TABLE `expt_template` (
  `id` bigint unsigned NOT NULL COMMENT 'id',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '空间 id',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '实验模板名称',
  `description` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '实验模板描述',
  `eval_set_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '评测集 id（模板创建后不可修改）',
  `eval_set_version_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '评测集默认版本 id',
  `target_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '评估对象 id（模板创建后不可修改）',
  `target_type` bigint unsigned NOT NULL DEFAULT '0' COMMENT '评估对象类型',
  `target_version_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '评估对象默认版本 id',
  `expt_type` int unsigned NOT NULL DEFAULT '1' COMMENT '实验类型，offline:1,online:2...',
  `template_conf` blob COMMENT '实验模板配置，包含评估器列表、字段映射、加权配置、默认并发及调度等，json',
  `expt_info` blob COMMENT '实验运行状态，包含创建实验数量，最后一次实验执行状态，json',
  `created_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '创建人',
  `updated_by` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '更新人',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_space_id_name_deleted_at` (`space_id`,`name`,`deleted_at`),
  KEY `idx_space_id_created_by_deleted_at` (`space_id`,`created_by`,`deleted_at`),
  KEY `idx_space_id_eval_set_id_deleted_at` (`space_id`,`eval_set_id`,`deleted_at`),
  KEY `idx_space_id_target_id_deleted_at` (`space_id`,`target_id`,`deleted_at`),
  KEY `idx_space_id_expt_type_deleted_at` (`space_id`,`expt_type`,`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_template';

CREATE TABLE `expt_template_evaluator_ref` (
  `id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'id',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '空间 id',
  `expt_template_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '实验模板 id',
  `evaluator_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '评估器 id',
  `evaluator_version_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '评估器版本 id',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `idx_space_id_expt_template_id` (`space_id`,`expt_template_id`),
  KEY `idx_space_id_evaluator_id` (`space_id`,`evaluator_id`),
  KEY `idx_space_id_evaluator_version_id` (`space_id`,`evaluator_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_template_evaluator_ref';

CREATE TABLE `expt_turn_annotate_record_ref` (
  `id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´ id',
  `expt_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'å®žéªŒ id',
  `expt_turn_result_id` bigint unsigned NOT NULL COMMENT 'å®žéªŒ turn result id',
  `tag_key_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ ‡ç­¾ id',
  `annotate_record_id` bigint unsigned NOT NULL COMMENT 'äººå·¥æ ‡æ³¨ç»“æžœ id',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_space_expt_turn_result_tag_key_id` (`space_id`,`expt_id`,`expt_turn_result_id`,`tag_key_id`),
  KEY `idx_turn_annotate_record_id` (`space_id`,`expt_turn_result_id`,`annotate_record_id`),
  KEY `idx_turn_tag_key_id` (`space_id`,`expt_turn_result_id`,`tag_key_id`),
  KEY `idx_space_expt_tag_key_id` (`space_id`,`expt_id`,`tag_key_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_turn_annotate_record_ref';

CREATE TABLE `expt_turn_evaluator_result_ref` (
  `id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´ id',
  `expt_turn_result_id` bigint unsigned NOT NULL COMMENT 'å®žéªŒ turn result id',
  `evaluator_version_id` bigint unsigned NOT NULL COMMENT 'è¯„ä¼°å™¨ç‰ˆæœ¬ id',
  `evaluator_result_id` bigint unsigned NOT NULL COMMENT 'è¯„ä¼°å™¨ç»“æžœ id',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `expt_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'å®žéªŒ id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_space_expt_turn_result_evaluator` (`space_id`,`expt_id`,`expt_turn_result_id`,`evaluator_version_id`),
  KEY `idx_turn_evaluator_result` (`space_id`,`expt_turn_result_id`,`evaluator_result_id`),
  KEY `idx_turn_evaluator_version` (`space_id`,`expt_turn_result_id`,`evaluator_version_id`),
  KEY `idx_expt_evaluator_result` (`space_id`,`expt_id`,`evaluator_result_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_turn_evaluator_result_ref';

CREATE TABLE `expt_turn_result` (
  `id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´ id',
  `expt_id` bigint unsigned NOT NULL COMMENT 'å®žéªŒ id',
  `expt_run_id` bigint unsigned NOT NULL COMMENT 'å®žéªŒè¿è¡Œ id',
  `item_id` bigint unsigned NOT NULL COMMENT 'item_id',
  `turn_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'turn_id',
  `turn_idx` int unsigned DEFAULT NULL COMMENT 'turn åºå·',
  `status` int unsigned NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `trace_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'trace_id',
  `log_id` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ—¥å¿— id',
  `target_result_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'target_result_id',
  `err_msg` blob COMMENT 'é”™è¯¯ä¿¡æ¯',
  `weighted_score` decimal(10,4) DEFAULT NULL COMMENT '加权汇总得分',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_expt_item_turn` (`space_id`,`expt_id`,`item_id`,`turn_id`),
  KEY `idx_expt_status` (`space_id`,`expt_id`,`status`),
  KEY `idx_expt_item_turn_idx` (`space_id`,`expt_id`,`item_id`,`turn_idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_turn_result';

CREATE TABLE `expt_turn_result_filter_key_mapping` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'è‡ªå¢žä¸»é”®',
  `space_id` bigint NOT NULL COMMENT 'ç©ºé—´id',
  `expt_id` bigint NOT NULL COMMENT 'å®žéªŒid',
  `from_field` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ç­›é€‰é¡¹å”¯ä¸€é”®ï¼Œè¯„ä¼°å™¨: evaluator_version_idï¼Œäººå·¥æ ‡å‡†ï¼štag_key_id',
  `to_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ckä¾§çš„map keyï¼Œè¯„ä¼°å™¨ï¼škey1 ~ key10ï¼Œäººå·¥æ ‡å‡†ï¼škey1 ~ key100',
  `field_type` int NOT NULL COMMENT 'æ˜ å°„ç±»åž‹ï¼ŒEvaluator â€”â€” 1ï¼Œäººå·¥æ ‡æ³¨â€”â€” 2',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `created_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'åˆ›å»ºäºº',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_idx_space_expt_from_type` (`space_id`,`expt_id`,`field_type`,`from_field`)
) ENGINE=InnoDB AUTO_INCREMENT=6692 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_turn_result_filteräºŒçº§keyæ˜ å°„è¡¨';

CREATE TABLE `expt_turn_result_run_log` (
  `id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'id',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´ id',
  `expt_id` bigint unsigned NOT NULL COMMENT 'å®žéªŒ id',
  `expt_run_id` bigint unsigned NOT NULL COMMENT 'å®žéªŒè¿è¡Œ id',
  `item_id` bigint unsigned NOT NULL COMMENT 'item_id',
  `turn_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'turn_id',
  `status` int unsigned NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  `trace_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'trace_id',
  `log_id` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ—¥å¿— id',
  `target_result_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'target_result_id',
  `evaluator_result_ids` blob COMMENT 'evaluator_result_idsï¼Œjson list æ ¼å¼',
  `err_msg` blob COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_expt_run_item_turn` (`space_id`,`expt_id`,`expt_run_id`,`item_id`,`turn_id`),
  KEY `idx_expt_item_turn` (`space_id`,`expt_id`,`item_id`,`turn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_item_result_run_log';

CREATE TABLE `expt_turn_result_tag_ref` (
  `id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'id',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ id',
  `expt_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'å®žéªŒ id',
  `tag_key_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'æ ‡ç­¾ id',
  `total_cnt` int NOT NULL DEFAULT '0' COMMENT 'total_cnt',
  `complete_cnt` int NOT NULL DEFAULT '0' COMMENT 'complete_cnt',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` timestamp NULL DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_space_tag_key_id` (`space_id`,`expt_id`,`tag_key_id`),
  KEY `idx_space_expt` (`space_id`,`expt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='expt_turn_result_tag_ref';

CREATE TABLE `model_request_record` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'è‡ªå¢žä¸»é”®ID',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´id',
  `user_id` varchar(256) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'user id',
  `usage_scene` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åœºæ™¯',
  `usage_scene_entity_id` varchar(256) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åœºæ™¯å®žä½“id',
  `frame` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ä½¿ç”¨çš„æ¡†æž¶ï¼Œå¦‚eino',
  `protocol` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ä½¿ç”¨çš„åè®®ï¼Œå¦‚ark/deepseekç­‰',
  `model_identification` varchar(1024) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ¨¡åž‹å”¯ä¸€æ ‡è¯†',
  `model_ak` varchar(1024) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ¨¡åž‹çš„AK',
  `model_id` varchar(256) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'model id',
  `model_name` varchar(1024) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ¨¡åž‹å±•ç¤ºåç§°',
  `input_token` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'è¾“å…¥tokenæ•°é‡',
  `output_token` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'è¾“å‡ºtokenæ•°é‡',
  `logid` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'logid',
  `error_code` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'error_code',
  `error_msg` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'error_msg',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_space_id_create_time` (`space_id`,`created_at`) USING BTREE COMMENT 'space_id_create_time'
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='æ¨¡åž‹æµé‡è®°å½•å¼€æºè¡¨';

CREATE TABLE `observability_trajectory_config` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `workspace_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT '空间 ID',
  `filter` json DEFAULT NULL COMMENT 'trace展示的过滤配置',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '创建人',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `updated_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '修改人',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除, 0 表示未删除, 1 表示已删除',
  `deleted_at` datetime DEFAULT NULL COMMENT '删除时间',
  `deleted_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '删除人',
  PRIMARY KEY (`id`),
  KEY `idx_space_id` (`workspace_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='观测轨迹配置';

CREATE TABLE `observability_view` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `enterprise_id` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ä¼ä¸šid',
  `workspace_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ ID',
  `view_name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'è§†å›¾åç§°',
  `platform_type` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ•°æ®æ¥æº',
  `span_list_type` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åˆ—è¡¨ä¿¡æ¯',
  `filters` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'è¿‡æ»¤æ¡ä»¶ä¿¡æ¯',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºäºº',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'ä¿®æ”¹æ—¶é—´',
  `updated_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ä¿®æ”¹äºº',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'æ˜¯å¦åˆ é™¤, 0 è¡¨ç¤ºæœªåˆ é™¤, 1 è¡¨ç¤ºå·²åˆ é™¤',
  `deleted_at` datetime DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `deleted_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'åˆ é™¤äºº',
  PRIMARY KEY (`id`),
  KEY `idx_space_id_created_by` (`workspace_id`,`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='è§‚æµ‹è§†å›¾ä¿¡æ¯';

CREATE TABLE `prompt_basic` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´ID',
  `prompt_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'Prompt key',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'Promptåç§°',
  `description` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'æè¿°',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºäºº',
  `updated_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'æ›´æ–°äºº',
  `commit_status` tinyint NOT NULL DEFAULT '0' COMMENT 'æäº¤çŠ¶æ€',
  `latest_version` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'æœ€æ–°ç‰ˆæœ¬',
  `latest_commit_time` datetime DEFAULT NULL COMMENT 'æœ€æ–°æäº¤æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ—¶é—´',
  `prompt_type` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'normal' COMMENT 'Prompt类型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_space_id_prompt_key_deleted_at` (`space_id`,`prompt_key`,`deleted_at`),
  KEY `idx_created_at` (`created_at`) USING BTREE,
  KEY `idx_pid_ptype_delat` (`space_id`,`prompt_type`,`deleted_at`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7603228121373868034 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='PromptåŸºç¡€è¡¨';

CREATE TABLE `prompt_commit` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´ID',
  `prompt_id` bigint unsigned NOT NULL COMMENT 'Prompt ID',
  `prompt_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Prompt key',
  `template_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'normal' COMMENT 'æ¨¡ç‰ˆç±»åž‹',
  `messages` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'æ‰˜ç®¡æ¶ˆæ¯åˆ—è¡¨',
  `model_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'æ¨¡åž‹é…ç½®',
  `variable_defs` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'å˜é‡å®šä¹‰',
  `tools` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'tools',
  `tool_call_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'toolè°ƒç”¨é…ç½®',
  `version` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ç‰ˆæœ¬',
  `base_version` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æ¥æºç‰ˆæœ¬',
  `committed_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'æäº¤äºº',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'æäº¤ç‰ˆæœ¬æè¿°',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `ext_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'Extended information field',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_prompt_id_version` (`prompt_id`,`version`),
  KEY `idx_prompt_key_version` (`prompt_key`,`version`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7540967127478435842 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Commitè¡¨';

CREATE TABLE `prompt_commit_label_mapping` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´ID',
  `prompt_id` bigint unsigned NOT NULL COMMENT 'Prompt ID',
  `label_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Labelå”¯ä¸€æ ‡è¯†',
  `prompt_version` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Promptç‰ˆæœ¬',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºäºº',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'æ›´æ–°äºº',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_prompt_id_label_key_deleted_at` (`prompt_id`,`label_key`,`deleted_at`),
  KEY `idx_prompt_id_version` (`prompt_id`,`prompt_version`) USING BTREE,
  KEY `idx_created_at` (`created_at`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Promptæäº¤ç‰ˆæœ¬å’ŒLabelå…³è”è¡¨';

CREATE TABLE `prompt_debug_context` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `prompt_id` bigint NOT NULL DEFAULT '0' COMMENT 'prompt id',
  `user_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'user id',
  `mock_contexts` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'ä¸Šä¸‹æ–‡ä¿¡æ¯ï¼Œjsonæ ¼å¼',
  `mock_variables` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'mockå˜é‡å€¼ï¼Œjsonæ ¼å¼',
  `mock_tools` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'mock toolç»“æžœï¼Œjsonæ ¼å¼',
  `debug_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'è°ƒè¯•é…ç½®',
  `compare_config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'è®­ç»ƒåœºé…ç½®',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_prompt_id_user_id` (`prompt_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7553200131282042882 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='ç”¨æˆ·è°ƒè¯•promptä¸Šä¸‹æ–‡ä¿¡æ¯è¡¨';

CREATE TABLE `prompt_debug_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `prompt_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Prompt ID',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'ç©ºé—´ID',
  `prompt_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'prompt key',
  `version` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'version',
  `input_tokens` bigint NOT NULL DEFAULT '0' COMMENT 'input_tokens',
  `output_tokens` bigint NOT NULL DEFAULT '0' COMMENT 'output_tokens',
  `started_at` bigint unsigned DEFAULT '0' COMMENT 'è¯·æ±‚å¼€å§‹æ¯«ç§’æ—¶é—´æˆ³',
  `ended_at` bigint unsigned DEFAULT '0' COMMENT 'å“åº”ç»“æŸæ¯«ç§’æ—¶é—´æˆ³',
  `cost_ms` bigint unsigned DEFAULT '0' COMMENT 'å“åº”è€—æ—¶æ¯«ç§’',
  `status_code` int DEFAULT NULL COMMENT 'çŠ¶æ€ç ',
  `debugged_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT 'æ‰§è¡ŒäººUserID',
  `debug_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'debug_id',
  `debug_step` int NOT NULL DEFAULT '1' COMMENT 'debug_step',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_prompt_id_debugged_by_started_at` (`prompt_id`,`debugged_by`,`started_at`) USING BTREE,
  KEY `idx_debug_id_step` (`debug_id`,`debug_step`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7553200127742050306 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='debugè¡¨';

CREATE TABLE `prompt_label` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®ID',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´ID',
  `label_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Labelå”¯ä¸€æ ‡è¯†',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'åˆ›å»ºäºº',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'æ›´æ–°äºº',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_space_id_label_key_deleted_at` (`space_id`,`label_key`,`deleted_at`),
  KEY `idx_created_at` (`created_at`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Prompt Labelè¡¨';

CREATE TABLE `prompt_relation` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `space_id` bigint unsigned NOT NULL COMMENT '空间ID',
  `main_prompt_id` bigint unsigned NOT NULL COMMENT '主Prompt ID',
  `main_prompt_version` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '主Prompt版本',
  `main_draft_user_id` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '主Prompt草稿Owner',
  `sub_prompt_id` bigint unsigned NOT NULL COMMENT '子Prompt ID',
  `sub_prompt_version` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '子Prompt版本',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_main_prompt_id_version` (`main_prompt_id`,`main_prompt_version`) COMMENT '主prompt_id_版本',
  KEY `idx_main_prompt_id_user` (`main_prompt_id`,`main_draft_user_id`) COMMENT '主prompt_id_user',
  KEY `idx_sub_prompt_id_version_create_time` (`sub_prompt_id`,`sub_prompt_version`,`create_time`) COMMENT '子prompt_id_版本'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Prompt关联表';

CREATE TABLE `prompt_user_draft` (
  `id` bigint unsigned NOT NULL COMMENT 'ä¸»é”®ID',
  `space_id` bigint unsigned NOT NULL COMMENT 'ç©ºé—´ID',
  `prompt_id` bigint unsigned NOT NULL COMMENT 'Prompt ID',
  `user_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'ç”¨æˆ·ID',
  `template_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'Normal' COMMENT 'æ¨¡ç‰ˆç±»åž‹',
  `messages` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'æ‰˜ç®¡æ¶ˆæ¯åˆ—è¡¨',
  `model_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'æ¨¡åž‹é…ç½®',
  `variable_defs` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'å˜é‡å®šä¹‰',
  `tools` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'tools',
  `tool_call_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'toolè°ƒç”¨é…ç½®',
  `base_version` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'è‰ç¨¿å…³è”ç‰ˆæœ¬',
  `is_draft_edited` tinyint NOT NULL DEFAULT '0' COMMENT 'è‰ç¨¿å†…å®¹æ˜¯å¦åŸºäºŽBaseVersionæœ‰å˜æ›´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ—¶é—´',
  `ext_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'Extended information field',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_prompt_id_user_id_deleted_at` (`prompt_id`,`user_id`,`deleted_at`),
  KEY `idx_prompt_id_user_id` (`prompt_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Draftè¡¨';

CREATE TABLE `space` (
  `id` bigint unsigned NOT NULL COMMENT 'Primary Key ID, Space ID',
  `owner_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Owner ID',
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Space Name',
  `description` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Space Description',
  `space_type` tinyint NOT NULL DEFAULT '0' COMMENT 'Space Type, 1: Personal, 2: Team',
  `icon_uri` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Icon URI',
  `created_by` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Creator ID',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_owner_id` (`owner_id`),
  KEY `idx_creator_id` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Space Table';

CREATE TABLE `space_user` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key ID, Auto Increment',
  `space_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'Space ID',
  `user_id` bigint unsigned NOT NULL DEFAULT '0' COMMENT 'User ID',
  `role_type` int NOT NULL DEFAULT '3' COMMENT 'Role Type: 1.owner 2.admin 3.member',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_space_user` (`space_id`,`user_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Space Member Table';

CREATE TABLE `tag_key` (
  `id` bigint unsigned NOT NULL COMMENT 'ä¸»é”®id',
  `app_id` int NOT NULL DEFAULT '0' COMMENT 'application id',
  `space_id` bigint unsigned NOT NULL COMMENT 'å½’å±žspace id,åšåˆ†ç‰‡é”®',
  `version_num` int NOT NULL DEFAULT '0' COMMENT 'tagè‡ªå¢žç‰ˆæœ¬',
  `version` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'tagç‰ˆæœ¬æ–‡æ¡ˆ',
  `tag_key_id` bigint unsigned NOT NULL COMMENT 'tag idï¼Œå”¯ä¸€æ ‡è¯†ä¸€ä¸ªæ ‡ç­¾',
  `tag_key_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'tagåç§°',
  `description` varchar(2000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'tagæè¿°',
  `parent_key_id` bigint unsigned DEFAULT NULL COMMENT 'çº§è”æ ‡ç­¾åœºæ™¯,ä¸Šå±‚tag key id',
  `created_at` timestamp NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL COMMENT 'æ›´æ–°æ—¶é—´',
  `change_log` json NOT NULL COMMENT 'å˜æ›´æ—¥å¿—',
  `status` varchar(32) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'tagçŠ¶æ€,active,inactive,deprecated',
  `tag_type` varchar(32) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'tagç±»åž‹,tag,option',
  `created_by` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'åˆ›å»ºè€…',
  `updated_by` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'æ›´æ–°è€…',
  `tag_target_type` varchar(256) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'tagç›®æ ‡å¯¹è±¡åˆ—è¡¨,resource|dataset_item,å¤šä¸ªå€¼ç”±,åˆ†éš”',
  `content_type` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'categorical' COMMENT 'å†…å®¹ç±»åž‹: è‡ªç”±æ–‡æœ¬,è¿žç»­åˆ†å€¼,åˆ†ç±»,å¸ƒå°”å€¼',
  `spec` json DEFAULT NULL COMMENT 'æ ‡ç­¾è§„æ ¼',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_space_id_tag_key_id_version_num_tag_type` (`space_id`,`tag_key_id`,`version_num`,`tag_type`),
  KEY `idx_space_id_tag_type_status_tag_key_name` (`space_id`,`tag_type`,`status`,`tag_key_name`),
  KEY `idx_space_id_tag_type_status_tag_created_by_tag_key_name` (`space_id`,`tag_type`,`status`,`created_by`,`tag_key_name`),
  KEY `idx_space_id_tag_type_status_content_type` (`space_id`,`tag_type`,`status`,`content_type`),
  KEY `idx_space_id_tag_type_status_updated_at` (`space_id`,`tag_type`,`status`,`updated_at`),
  KEY `idx_space_id_tag_type_status_created_at` (`space_id`,`tag_type`,`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='tagå…ƒæ•°æ®è¡¨';

CREATE TABLE `tag_value` (
  `id` bigint unsigned NOT NULL COMMENT 'ä¸»é”®id',
  `app_id` int NOT NULL DEFAULT '0' COMMENT 'application id',
  `space_id` bigint unsigned NOT NULL COMMENT 'å½’å±žspace id,åšåˆ†ç‰‡é”®',
  `tag_key_id` bigint unsigned NOT NULL COMMENT 'tag idï¼Œå”¯ä¸€æ ‡è¯†ä¸€ä¸ªæ ‡ç­¾',
  `tag_value_id` bigint unsigned NOT NULL COMMENT 'tag value idï¼Œå”¯ä¸€æ ‡è¯†ä¸€ä¸ªæ ‡ç­¾',
  `tag_value_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'tag valueåç§°',
  `description` varchar(2000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'tag valueæè¿°',
  `parent_value_id` bigint unsigned NOT NULL COMMENT 'çº§è”æ ‡ç­¾åœºæ™¯,ä¸Šå±‚tag value id',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `version_num` int NOT NULL DEFAULT '0' COMMENT 'tagè‡ªå¢žç‰ˆæœ¬',
  `status` varchar(32) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'çŠ¶æ€,active,inactive,deprecated',
  `created_by` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'åˆ›å»ºè€…',
  `updated_by` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'æ›´æ–°è€…',
  PRIMARY KEY (`id`),
  KEY `idx_space_id_tag_key_id_version_num` (`space_id`,`tag_key_id`,`version_num`),
  KEY `idx_space_id_tag_value_id_version_num` (`space_id`,`tag_value_id`,`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='tag valueå…ƒæ•°æ®è¡¨';

CREATE TABLE `task` (
  `id` bigint unsigned NOT NULL COMMENT 'Task ID',
  `workspace_id` bigint unsigned NOT NULL COMMENT '空间ID',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '任务名称',
  `description` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '任务描述',
  `task_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '任务类型',
  `task_status` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '任务状态',
  `task_detail` json DEFAULT NULL COMMENT '任务运行状态详情',
  `span_filter` json DEFAULT NULL COMMENT 'span 过滤条件',
  `effective_time` json DEFAULT NULL COMMENT '生效时间',
  `backfill_effective_time` json DEFAULT NULL COMMENT '历史回溯生效时间',
  `sampler` json DEFAULT NULL COMMENT '采样器',
  `task_config` json DEFAULT NULL COMMENT '相关任务的配置信息',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  `created_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '创建人',
  `updated_by` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '更新人',
  `task_source` varchar(50) COLLATE utf8mb4_general_ci DEFAULT 'user' COMMENT '任务来源',
  PRIMARY KEY (`id`),
  KEY `idx_space_id_status` (`workspace_id`,`task_status`),
  KEY `idx_space_id_type` (`workspace_id`,`task_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='任务信息';

CREATE TABLE `user` (
  `id` bigint NOT NULL COMMENT 'Primary Key ID',
  `name` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'User Nickname',
  `unique_name` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'User Unique Name',
  `email` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Email',
  `password` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Password (Encrypted)',
  `description` varchar(512) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'User Description',
  `icon_uri` varchar(512) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Avatar URI',
  `user_verified` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'User Verification Status',
  `country_code` bigint NOT NULL DEFAULT '0' COMMENT 'Country Code',
  `session_key` varchar(512) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT 'Session Key',
  `deleted_at` bigint NOT NULL DEFAULT '0' COMMENT 'åˆ é™¤æ—¶é—´',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unique_name` (`unique_name`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `idx_session_key` (`session_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='User Table';

