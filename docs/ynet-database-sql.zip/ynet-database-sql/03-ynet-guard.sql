-- ============================================================
-- Ynet Guard Database Schema
-- Source: 172.93.101.237:2881 (OceanBase) / guard
-- Exported: 2026-03-17
-- ============================================================
CREATE DATABASE IF NOT EXISTS `guard` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `guard`;

CREATE TABLE `api_keys` (
  `id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `business_id` varchar(32) DEFAULT NULL,
  `key_hash` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `last_used_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `api_keys_OBFK_1773370795103993` FOREIGN KEY (`user_id`) REFERENCES `guard`.`users`(`id`) ON UPDATE RESTRICT ON DELETE SET NULL ,
  CONSTRAINT `api_keys_OBFK_1773370795103979` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `api_keys_OBFK_1773370795103964` FOREIGN KEY (`business_id`) REFERENCES `guard`.`shield_businesses`(`id`) ON UPDATE RESTRICT ON DELETE SET NULL ,
  UNIQUE KEY `key_hash` (`key_hash`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `audit_logs` (
  `id` varchar(32) NOT NULL,
  `request_id` varchar(64) NOT NULL,
  `trace_id` varchar(64) DEFAULT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `query` text NOT NULL,
  `session_id` varchar(64) DEFAULT NULL,
  `user_id` varchar(64) DEFAULT NULL,
  `scene` varchar(50) DEFAULT NULL,
  `passed` tinyint(1) NOT NULL,
  `action` varchar(20) NOT NULL,
  `source` varchar(20) DEFAULT NULL,
  `risk_level` varchar(20) DEFAULT NULL,
  `risk_type` varchar(50) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `matched_rule` varchar(64) DEFAULT NULL,
  `confidence` float DEFAULT NULL,
  `answer` text DEFAULT NULL,
  `total_ms` int(11) DEFAULT NULL,
  `model_check_ms` int(11) DEFAULT NULL,
  `kb_match_ms` int(11) DEFAULT NULL,
  `extra` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_id` (`request_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_audit_logs_created_at` (`created_at`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_audit_logs_tenant_id` (`tenant_id`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `categories` (
  `id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `parent_id` varchar(32) DEFAULT NULL,
  `sort_order` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `categories_OBFK_1773370782545380` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `categories_OBFK_1773370782545364` FOREIGN KEY (`parent_id`) REFERENCES `guard`.`categories`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT 
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `kb_entries` (
  `id` varchar(32) NOT NULL,
  `kb_id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `category_id` varchar(32) DEFAULT NULL,
  `keywords` json DEFAULT NULL,
  `semantic_text` text DEFAULT NULL,
  `risk_type` varchar(50) DEFAULT NULL,
  `risk_level` varchar(20) NOT NULL,
  `answer_template` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `version` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `kb_entries_OBFK_1773370788783622` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `kb_entries_OBFK_1773370788778068` FOREIGN KEY (`kb_id`) REFERENCES `guard`.`knowledge_bases`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `kb_entries_OBFK_1773370788771667` FOREIGN KEY (`category_id`) REFERENCES `guard`.`shield_categories`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT 
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `kb_vectors` (
  `id` varchar(64) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `kb_id` varchar(32) NOT NULL,
  `entry_id` varchar(32) NOT NULL,
  `vector` VECTOR(1024) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_id` (`tenant_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `idx_kb_id` (`kb_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `idx_entry_id` (`entry_id`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `knowledge_bases` (
  `id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `knowledge_bases_OBFK_1773370783115493` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  KEY `ix_knowledge_bases_is_system` (`is_system`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `operation_logs` (
  `id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `user_id` varchar(32) DEFAULT NULL,
  `action` varchar(20) NOT NULL,
  `resource` varchar(20) NOT NULL,
  `resource_id` varchar(32) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `operation_logs_OBFK_1773370789310207` FOREIGN KEY (`user_id`) REFERENCES `guard`.`users`(`id`) ON UPDATE RESTRICT ON DELETE SET NULL ,
  CONSTRAINT `operation_logs_OBFK_1773370789301714` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT 
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `shield_audit_logs` (
  `id` varchar(32) NOT NULL,
  `request_id` varchar(64) NOT NULL,
  `trace_id` varchar(64) DEFAULT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `product_id` varchar(32) NOT NULL,
  `product_code` varchar(50) NOT NULL,
  `business_id` varchar(32) NOT NULL,
  `business_code` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `content_type` varchar(20) NOT NULL,
  `client_ip` varchar(50) DEFAULT NULL,
  `user_id` varchar(64) DEFAULT NULL,
  `device_id` varchar(64) DEFAULT NULL,
  `passed` tinyint(1) NOT NULL,
  `action` varchar(20) NOT NULL,
  `hit_categories` json DEFAULT NULL,
  `hit_blocklist_id` varchar(32) DEFAULT NULL,
  `hit_blocklist_value` varchar(500) DEFAULT NULL,
  `ai_model_triggered` tinyint(1) NOT NULL,
  `ai_risk_type` varchar(50) DEFAULT NULL,
  `ai_risk_level` varchar(20) DEFAULT NULL,
  `ai_confidence` float DEFAULT NULL,
  `total_ms` int(11) DEFAULT NULL,
  `ai_check_ms` int(11) DEFAULT NULL,
  `kb_check_ms` int(11) DEFAULT NULL,
  `policy_check_ms` int(11) DEFAULT NULL,
  `blocklist_check_ms` int(11) DEFAULT NULL,
  `extra` json DEFAULT NULL,
  `review_status` varchar(20) DEFAULT NULL,
  `review_user_id` varchar(32) DEFAULT NULL,
  `review_at` datetime DEFAULT NULL,
  `review_remark` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_id` (`request_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_shield_audit_logs_action` (`action`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_shield_audit_logs_business_id` (`business_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_shield_audit_logs_created_at` (`created_at`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_shield_audit_logs_product_id` (`product_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_shield_audit_logs_tenant_id` (`tenant_id`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `shield_blocklist_entries` (
  `id` varchar(32) NOT NULL,
  `blocklist_id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `value` varchar(500) NOT NULL,
  `remark` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `shield_blocklist_entries_OBFK_1773370795657230` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `shield_blocklist_entries_OBFK_1773370795657204` FOREIGN KEY (`blocklist_id`) REFERENCES `guard`.`shield_blocklists`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  KEY `ix_shield_blocklist_entries_blocklist_id` (`blocklist_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_shield_blocklist_entries_tenant_id` (`tenant_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_shield_blocklist_entries_value` (`value`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `shield_blocklists` (
  `id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `list_type` varchar(20) NOT NULL,
  `mode` varchar(20) NOT NULL,
  `category_id` varchar(32) DEFAULT NULL,
  `risk_level` varchar(10) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `shield_blocklists_OBFK_1773370789818859` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `shield_blocklists_OBFK_1773370789811939` FOREIGN KEY (`category_id`) REFERENCES `guard`.`shield_categories`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  KEY `ix_shield_blocklists_tenant_id` (`tenant_id`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `shield_business_blocklists` (
  `id` varchar(32) NOT NULL,
  `business_id` varchar(32) NOT NULL,
  `blocklist_id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `shield_business_blocklists_OBFK_1773370800458689` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `shield_business_blocklists_OBFK_1773370800451487` FOREIGN KEY (`business_id`) REFERENCES `guard`.`shield_businesses`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `shield_business_blocklists_OBFK_1773370800451475` FOREIGN KEY (`blocklist_id`) REFERENCES `guard`.`shield_blocklists`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  KEY `ix_shield_business_blocklists_blocklist_id` (`blocklist_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_shield_business_blocklists_business_id` (`business_id`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `shield_businesses` (
  `id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `product_id` varchar(32) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `business_type` varchar(20) NOT NULL,
  `enable_ai_model` tinyint(1) NOT NULL,
  `enable_kb` tinyint(1) NOT NULL,
  `kb_category_ids` json DEFAULT NULL,
  `enable_blocklist` tinyint(1) NOT NULL,
  `default_action` varchar(20) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `shield_businesses_OBFK_1773370791612094` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `shield_businesses_OBFK_1773370791600653` FOREIGN KEY (`product_id`) REFERENCES `guard`.`shield_products`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  KEY `ix_shield_businesses_product_id` (`product_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_shield_businesses_tenant_id` (`tenant_id`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `shield_categories` (
  `id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `level` int(11) NOT NULL,
  `parent_id` varchar(32) DEFAULT NULL,
  `path` varchar(500) NOT NULL,
  `default_risk_level` varchar(10) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `shield_categories_OBFK_1773370784809150` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `shield_categories_OBFK_1773370784809142` FOREIGN KEY (`parent_id`) REFERENCES `guard`.`shield_categories`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  KEY `ix_shield_categories_tenant_id` (`tenant_id`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `shield_policy_configs` (
  `id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `business_id` varchar(32) NOT NULL,
  `category_id` varchar(32) NOT NULL,
  `action_r1` varchar(20) NOT NULL,
  `action_r2` varchar(20) NOT NULL,
  `action_r3` varchar(20) NOT NULL,
  `action_default` varchar(20) NOT NULL,
  `priority` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `shield_policy_configs_OBFK_1773370803376054` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `shield_policy_configs_OBFK_1773370803368979` FOREIGN KEY (`category_id`) REFERENCES `guard`.`shield_categories`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  CONSTRAINT `shield_policy_configs_OBFK_1773370803361440` FOREIGN KEY (`business_id`) REFERENCES `guard`.`shield_businesses`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  KEY `ix_shield_policy_configs_business_id` (`business_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_shield_policy_configs_category_id` (`category_id`) BLOCK_SIZE 16384 LOCAL,
  KEY `ix_shield_policy_configs_tenant_id` (`tenant_id`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `shield_products` (
  `id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `shield_products_OBFK_1773370786526127` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  KEY `ix_shield_products_tenant_id` (`tenant_id`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `tenants` (
  `id` varchar(32) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

CREATE TABLE `users` (
  `id` varchar(32) NOT NULL,
  `tenant_id` varchar(32) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(128) NOT NULL,
  `role` varchar(20) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `last_login_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `users_OBFK_1773370788236149` FOREIGN KEY (`tenant_id`) REFERENCES `guard`.`tenants`(`id`) ON UPDATE RESTRICT ON DELETE RESTRICT ,
  UNIQUE KEY `uq_users_tenant_username` (`tenant_id`, `username`) BLOCK_SIZE 16384 LOCAL
) DEFAULT CHARSET = utf8mb4 ROW_FORMAT = DYNAMIC COMPRESSION = 'zstd_1.3.8' REPLICA_NUM = 1 BLOCK_SIZE = 16384 USE_BLOOM_FILTER = FALSE TABLET_SIZE = 134217728 PCTFREE = 0;

